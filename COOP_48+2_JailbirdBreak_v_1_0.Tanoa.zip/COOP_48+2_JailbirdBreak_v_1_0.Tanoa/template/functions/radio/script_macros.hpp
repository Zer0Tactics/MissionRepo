// XPT Script defines
#include "..\..\script_macros.hpp"

#define XPT_DEF_MODULE "XPT-RADIO"