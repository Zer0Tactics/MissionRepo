// Check if the template is enabled
//define TEMPLATE_ENABLED_CHECK if !([] call XPT_fnc_enabled) exitWith {};
