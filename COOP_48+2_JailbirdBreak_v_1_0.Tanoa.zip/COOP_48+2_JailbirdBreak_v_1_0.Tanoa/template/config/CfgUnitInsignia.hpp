// Unit Insignias
// Usually visible on the sleeve of a unit
// https://community.bistudio.com/wiki/Arma_3_Unit_Insignia

class tmtm
{
	displayName = "TMTM";
	author = "TMTM";
	texture = "template\media\insignia\tmtm.paa";
};
class tmtm_patch
{
	displayName = "TMTM (Patch)";
	author = "TMTM";
	texture = "template\media\insignia\tmtm_insignia.paa";
};