Copyright 2023 Superxpdude

The XP template is released under the Arma Public License - Share Alike (APL-SA)
The full details about the license can be found at the link below:
https://www.bohemia.net/community/licenses/arma-public-license-share-alike

This license means that you are free to use, distribute, and modify the XP template as long as you abide by the following conditions:
 - You may use the XP template in your work in an unmodified form.
 - You may modify the XP template as long as you maintain existing attribution, and do not attempt to attribute additional code to the original author(s).
 - You may not use the XP template in any commercial application without consent from Superxpdude.
 - You may not adapt the XP template for use with games other than Arma.
 - Any modified versions of, or works created with the XP template **must** be redistributed under the Arma Public License - Share Alike.