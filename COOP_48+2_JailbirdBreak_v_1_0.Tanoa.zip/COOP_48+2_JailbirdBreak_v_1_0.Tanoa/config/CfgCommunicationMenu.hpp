// Communication Menu
// Used for being able to call in supports or trigger other mission events. Similar to setting triggers to radio alpha/bravo/etc.
// https://community.bistudio.com/wiki/Arma_3_Communication_Menu

/*
class exampleCommMenuItem
{
	text = "Example Item";
	submenu = "";
	expression = "player setDamage 1";
	icon = "";
	cursor = "";
	enable = "true"; // Expression for enabling item
	removeAfterExpressionCall = 1;
};
*/