// XPTloadouts.hpp
// Used for defining advanced respawn loadouts for players
// Default behaviour is to check if the player unit has a special loadout defined. Otherwise, it will check to see if the classname matches a loadout
// Advanced functionality allows mission creator to define exactly where items are placed in unit inventories
// Also supports sub-loadout randomization. If a loadout has sub-classes defined, the script will automatically select one of them to apply to the unit.
class loadouts
{	
	class example
	{
		displayName = "Example Loadout"; // Currently unused, basically just a human-readable name for the loadout
		
		// Weapon definitions all use the following format:
		// {Weapon Classname, Suppressor, Pointer (Laser/Flashlight), Optic, [Primary magazine, ammo count], [Secondary Magazine (GL), ammo count], Bipod}
		// Any empty definitions must be defined as an empty string, or an empty array. Otherwise the loadout will not apply correctly.
		
		primaryWeapon[] = {"arifle_MXC_F", "", "acc_flashlight", "optic_ACO", {"30Rnd_65x39_caseless_mag",30}, {}, ""}; // Primary weapon definition
		secondaryWeapon[] = {"launch_B_Titan_short_F", "", "", "", {"Titan_AP", 1}, {}, ""}; // Secondary weapon (Launcher) definition.
		handgunWeapon[] = {"hgun_ACPC2_F", "", "", "", {"9Rnd_45ACP_Mag", 9}, {}, ""}; // Handgun definition
		binocular = "Binocular";
		
		uniformClass = "U_B_CombatUniform_mcam_tshirt";
		headgearClass = "H_Watchcap_blk";
		facewearClass = "";
		vestClass = "V_Chestrig_khk";
		backpackClass = "B_AssaultPack_mcamo";
		
		// Linked items requires all six definitions to be present. Use empty strings if you do not want to add that item.
		linkedItems[] = {"ItemMap", "ItemGPS", "ItemRadio", "ItemCompass", "ItemWatch", ""}; // Linked items for the unit, must follow the order of: Map, GPS, Radio, Compass, Watch, NVGs.
		
		// When placed in an item array, magazines should also have their ammo count defined
		uniformItems[] = {{"FirstAidKit", 3}, {"30Rnd_65x39_caseless_mag", 4, 30}}; // Items to place in uniform. Includes weapon magazines
		vestItems[] = {{"FirstAidKit", 3}, {"30Rnd_65x39_caseless_mag", 4, 30}}; // Items to place in vest. Includes weapon magazines
		backpackItems[] = {{"FirstAidKit", 3}, {"30Rnd_65x39_caseless_mag", 4, 30}}; // Items to place in backpack. Includes weapon magazines
		
		basicMedUniform[] = {}; // Items to be placed in the uniform only when basic medical is being used
		basicMedVest[] = {}; // Items to be placed in the vest only when basic medical is being used
		basicMedBackpack[] = {}; // Items to be placed in the backpack only when basic medical is being used
		
		advMedUniform[] = {}; // Items to be placed in the uniform only when advanced medical is being used
		advMedVest[] = {}; // Items to be placed in the vest only when advanced medical is being used
		advMedBackpack[] = {}; // Items to be placed in the backpack only when advanced medical is being used
	};
	
	class example_random
	{
		displayName = "Random Loadouts";
		class random_1
		{
			// Loadout info goes here
		};
		class random_2
		{
			// Loadout info goes here
		};
	};
	
	class CUP_B_BAF_Soldier_Officer_DPM {
		// Requires the following DLC:
		// Apex
		displayName = "CUP_B_BAF_Soldier_Officer_DPM";

		primaryWeapon[] = {"CUP_arifle_L85A2_GL","","CUP_acc_LLM_black","CUP_optic_SUSAT_PIP",{"CUP_30Rnd_556x45_Stanag_L85",30},{"CUP_1Rnd_HE_M203",1},""};
		secondaryWeapon[] = {};
		handgunWeapon[] = {"CUP_hgun_Glock17_blk","","","",{"CUP_17Rnd_9x19_glock17",17},{},""};
		binocular = "Laserdesignator_03";

		uniformClass = "CUP_U_B_BAF_DPM_UBACSROLLEDKNEE";
		headgearClass = "CUP_H_BAF_PARA_PRRUNDER_BERET";
		vestClass = "CUP_V_B_BAF_DPM_Osprey_Mk3_Officer";
		backpackClass = "FRXA_tf_rt1523g_big_Ranger_Green";

		linkedItems[] = {"ItemMap","ItemcTab","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ACE_EntrenchingTool",1},{"ACE_MapTools",1},{"Laserbatteries",1,1}};
		vestItems[] = {{"CUP_17Rnd_9x19_glock17",2,17},{"CUP_30Rnd_556x45_Stanag_L85",8,30},{"SmokeShell",2,1},{"SmokeShellGreen",2,1},{"CUP_HandGrenade_M67",2,1}};
		backpackItems[] = {{"1Rnd_HE_Grenade_shell",8,1},{"1Rnd_SmokeRed_Grenade_shell",2,1},{"1Rnd_Smoke_Grenade_shell",2,1}};

		basicMedUniform[] = {{"ACE_packingBandage",5},{"ACE_epinephrine",2},{"ACE_morphine",2},{"ACE_splint",2},{"ACE_tourniquet",1}};
		basicMedVest[] = {};
		basicMedBackpack[] = {};
	};

	class B_G_officer_F {
		// Requires the following DLC:
		// Apex
		displayName = "B_G_officer_F";

		primaryWeapon[] = {"CUP_arifle_FNFAL_woodland","","","",{"CUP_20Rnd_762x51_FNFAL_Woodland_M",20},{},""};
		secondaryWeapon[] = {};
		handgunWeapon[] = {};
		binocular = "Binocular";

		uniformClass = "tmtm_u_guerillaGarment_brownSand";
		headgearClass = "CUP_H_C_Beret_02";
		vestClass = "tmtm_v_6b3PioneerGL_oliveCamo";
		backpackClass = "FRXA_tf_rt1523g_big_Ranger_Green";

		linkedItems[] = {"ItemMap","","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ACE_EntrenchingTool",1},{"ACE_MapTools",1}};
		vestItems[] = {{"SmokeShell",2,1},{"CUP_HandGrenade_M67",2,1},{"CUP_20Rnd_762x51_FNFAL_M",9,20}};
		backpackItems[] = {{"CUP_20Rnd_762x51_FNFAL_M",12,20}};

		basicMedUniform[] = {{"ACE_packingBandage",5},{"ACE_epinephrine",2},{"ACE_morphine",2},{"ACE_splint",2},{"ACE_tourniquet",2}};
		basicMedVest[] = {};
		basicMedBackpack[] = {};
	};

	class CUP_B_BAF_Soldier_SquadLeader_DPM {
		// Requires the following DLC:
		// Apex
		displayName = "CUP_B_BAF_Soldier_SquadLeader_DPM";

		primaryWeapon[] = {"CUP_arifle_L85A2_GL_Elcan_Laser","","CUP_acc_LLM_black","CUP_optic_SUSAT_PIP",{"CUP_30Rnd_556x45_Stanag_L85",30},{"CUP_1Rnd_HE_M203",1},""};
		secondaryWeapon[] = {};
		handgunWeapon[] = {"CUP_hgun_Glock17_blk","","","",{"CUP_17Rnd_9x19_glock17",17},{},""};
		binocular = "Laserdesignator_03";

		uniformClass = "CUP_U_B_BAF_DPM_UBACSROLLEDKNEE";
		headgearClass = "CUP_H_BAF_DPM_Mk6_EMPTY_PRR";
		vestClass = "CUP_V_B_BAF_DPM_Osprey_Mk3_Officer";
		backpackClass = "FRXA_tf_rt1523g_big_Ranger_Green";

		linkedItems[] = {"ItemMap","ItemcTab","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ACE_EntrenchingTool",1},{"ACE_MapTools",1},{"Laserbatteries",1,1}};
		vestItems[] = {{"CUP_17Rnd_9x19_glock17",2,17},{"CUP_30Rnd_556x45_Stanag_L85",8,30},{"SmokeShell",2,1},{"SmokeShellGreen",2,1},{"CUP_HandGrenade_M67",2,1}};
		backpackItems[] = {{"1Rnd_HE_Grenade_shell",8,1},{"1Rnd_SmokeRed_Grenade_shell",2,1},{"1Rnd_Smoke_Grenade_shell",2,1}};

		basicMedUniform[] = {{"ACE_packingBandage",5},{"ACE_epinephrine",2},{"ACE_morphine",2},{"ACE_splint",2},{"ACE_tourniquet",1}};
		basicMedVest[] = {};
		basicMedBackpack[] = {};
	};

	class CUP_B_BAF_Soldier_TeamLeader_DPM {
		// Requires the following DLC:
		// Apex
		displayName = "CUP_B_BAF_Soldier_TeamLeader_DPM";

		primaryWeapon[] = {"CUP_arifle_L85A2_GL","","CUP_acc_LLM_black","CUP_optic_SUSAT_PIP",{"CUP_30Rnd_556x45_Stanag_L85",30},{"CUP_1Rnd_HE_M203",1},""};
		secondaryWeapon[] = {};
		handgunWeapon[] = {"CUP_hgun_Glock17_blk","","","",{"CUP_17Rnd_9x19_glock17",17},{},""};
		binocular = "Laserdesignator_03";

		uniformClass = "CUP_U_B_BAF_DPM_UBACSROLLEDKNEE";
		headgearClass = "CUP_H_BAF_DPM_Mk6_EMPTY_PRR";
		vestClass = "CUP_V_B_BAF_DPM_Osprey_Mk3_Officer";
		backpackClass = "FRXA_tf_rt1523g_big_Ranger_Green";

		linkedItems[] = {"ItemMap","ItemcTab","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ACE_EntrenchingTool",1},{"ACE_MapTools",1},{"Laserbatteries",1,1}};
		vestItems[] = {{"CUP_17Rnd_9x19_glock17",2,17},{"CUP_30Rnd_556x45_Stanag_L85",8,30},{"SmokeShell",2,1},{"SmokeShellGreen",2,1},{"CUP_HandGrenade_M67",2,1}};
		backpackItems[] = {{"1Rnd_HE_Grenade_shell",5,1},{"1Rnd_SmokeRed_Grenade_shell",2,1},{"1Rnd_Smoke_Grenade_shell",2,1}};

		basicMedUniform[] = {{"ACE_packingBandage",5},{"ACE_epinephrine",2},{"ACE_morphine",2},{"ACE_splint",2},{"ACE_tourniquet",1}};
		basicMedVest[] = {};
		basicMedBackpack[] = {};
	};

	class B_G_Soldier_AR_F {
		// Requires the following DLC:
		// Apex
		displayName = "B_G_Soldier_AR_F";

		primaryWeapon[] = {"CUP_lmg_M60E4_norail_jungle","","","",{"CUP_100Rnd_TE4_LRT4_Red_Tracer_762x51_Belt_M",100},{},""};
		secondaryWeapon[] = {};
		handgunWeapon[] = {};
		binocular = "Binocular";

		uniformClass = "tmtm_u_guerillaGarment_greenLDF";
		headgearClass = "H_Simc_SVN_M1_Cl";
		facewearClass = "G_Shades_Blue";
		vestClass = "tmtm_v_6b3PioneerGL_oliveCamo";
		backpackClass = "B_simc_pack_trop_1_alt";

		linkedItems[] = {"ItemMap","","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ACE_EntrenchingTool",1},{"ACE_MapTools",1}};
		vestItems[] = {{"CUP_100Rnd_TE4_LRT4_Red_Tracer_762x51_Belt_M",2,100},{"SmokeShell",2,1}};
		backpackItems[] = {{"CUP_100Rnd_TE4_LRT4_Red_Tracer_762x51_Belt_M",1,100}};

		basicMedUniform[] = {{"ACE_packingBandage",5},{"ACE_epinephrine",2},{"ACE_morphine",2},{"ACE_splint",2},{"ACE_tourniquet",2}};
		basicMedVest[] = {};
		basicMedBackpack[] = {};
	};

	class B_G_Soldier_A_F {
		// Requires the following DLC:
		// Apex
		displayName = "B_G_Soldier_A_F";

		primaryWeapon[] = {"CUP_arifle_FNFAL_woodland","","","",{"CUP_20Rnd_762x51_FNFAL_M",20},{},""};
		secondaryWeapon[] = {};
		handgunWeapon[] = {};
		binocular = "Binocular";

		uniformClass = "tmtm_u_guerillaGarment_greenLDF";
		headgearClass = "H_Simc_SVN_M1_Cl";
		facewearClass = "G_Shades_Blue";
		vestClass = "tmtm_v_6b3PioneerGL_oliveCamo";
		backpackClass = "B_simc_pack_trop_1_alt";

		linkedItems[] = {"ItemMap","","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ACE_EntrenchingTool",1},{"ACE_MapTools",1}};
		vestItems[] = {{"SmokeShell",2,1},{"CUP_HandGrenade_M67",2,1},{"CUP_20Rnd_762x51_FNFAL_M",9,20}};
		backpackItems[] = {{"CUP_100Rnd_TE4_LRT4_Red_Tracer_762x51_Belt_M",4,100},{"CUP_20Rnd_762x51_FNFAL_M",2,20}};

		basicMedUniform[] = {{"ACE_packingBandage",5},{"ACE_epinephrine",2},{"ACE_morphine",2},{"ACE_splint",2},{"ACE_tourniquet",2}};
		basicMedVest[] = {};
		basicMedBackpack[] = {};
	};

	class B_G_Soldier_LAT2_F {
		// Requires the following DLC:
		// Apex
		displayName = "B_G_Soldier_LAT2_F";

		primaryWeapon[] = {"CUP_arifle_FNFAL_woodland","","","",{"CUP_20Rnd_762x51_FNFAL_Woodland_M",20},{},""};
		secondaryWeapon[] = {"CUP_launch_RPG26_Loaded","","","",{"CUP_RPG26_M",1},{},""};
		handgunWeapon[] = {};
		binocular = "Binocular";

		uniformClass = "U_BG_Guerilla1_2_F";
		headgearClass = "H_Simc_SVN_M1_Cl";
		vestClass = "tmtm_v_6b3PioneerAT_oliveCamo";
		backpackClass = "B_AssaultPack_rgr";

		linkedItems[] = {"ItemMap","","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ACE_EntrenchingTool",1},{"ACE_MapTools",1}};
		vestItems[] = {{"CUP_20Rnd_762x51_FNFAL_M",10,20}};
		backpackItems[] = {{"CUP_HandGrenade_M67",2,1},{"SmokeShell",2,1},{"CUP_20Rnd_762x51_FNFAL_M",10,20}};

		basicMedUniform[] = {{"ACE_packingBandage",5},{"ACE_epinephrine",2},{"ACE_morphine",2},{"ACE_splint",2},{"ACE_tourniquet",2}};
		basicMedVest[] = {};
		basicMedBackpack[] = {};
	};

	class B_G_Sharpshooter_F {
		// Requires the following DLC:
		// Apex
		displayName = "B_G_Sharpshooter_F";

		primaryWeapon[] = {"CUP_srifle_Remington700","","","CUP_optic_Remington_pip",{"CUP_6Rnd_762x51_R700",6},{},""};
		secondaryWeapon[] = {};
		handgunWeapon[] = {"CUP_hgun_PMM","","","",{"CUP_12Rnd_9x18_PMM_M",12},{},""};

		uniformClass = "tmtm_u_guerillaGarment_sandSyndikat";
		headgearClass = "H_Simc_SVN_M1_Cl";
		vestClass = "CUP_V_O_SLA_6B3_2_WDL";
		backpackClass = "CUP_B_AlicePack_Bedroll";

		linkedItems[] = {"ItemMap","","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ACE_EntrenchingTool",1},{"ACE_MapTools",1}};
		vestItems[] = {{"SmokeShell",2,1},{"CUP_6Rnd_762x51_R700",15,6},{"CUP_12Rnd_9x18_PMM_M",1,12}};
		backpackItems[] = {{"CUP_6Rnd_762x51_R700",15,6}};

		basicMedUniform[] = {{"ACE_packingBandage",5},{"ACE_epinephrine",2},{"ACE_morphine",2},{"ACE_splint",2},{"ACE_tourniquet",2}};
		basicMedVest[] = {};
		basicMedBackpack[] = {};
	};

	class CUP_B_BAF_Soldier_Medic_DPM {
		// Requires the following DLC:
		// Apex
		displayName = "CUP_B_BAF_Soldier_Medic_DPM";

		primaryWeapon[] = {"CUP_arifle_L85A2_ACOG_Laser","","CUP_acc_LLM_black","CUP_optic_SUSAT_PIP",{"CUP_30Rnd_556x45_Stanag_L85",30},{},""};
		secondaryWeapon[] = {};
		handgunWeapon[] = {"CUP_hgun_Glock17_blk","","","",{"CUP_17Rnd_9x19_glock17",17},{},""};
		binocular = "Binocular";

		uniformClass = "CUP_U_B_BAF_DPM_UBACSTSHIRTKNEE";
		headgearClass = "CUP_H_BAF_DPM_Mk6_EMPTY_PRR";
		vestClass = "CUP_V_B_BAF_DPM_Osprey_Mk3_Medic";
		backpackClass = "CUP_B_Motherlode_Medic_MTP";

		linkedItems[] = {"ItemMap","ItemcTab","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ACE_EntrenchingTool",1},{"ACE_MapTools",1},{"ItemcTabHCam",1},{"SmokeShell",2,1},{"SmokeShellGreen",2,1}};
		vestItems[] = {{"CUP_30Rnd_556x45_Stanag_L85",8,30},{"CUP_17Rnd_9x19_glock17",2,17}};
		backpackItems[] = {};

		basicMedUniform[] = {};
		basicMedVest[] = {};
		basicMedBackpack[] = {{"ACE_packingBandage",40},{"ACE_bloodIV_500",8},{"ACE_bloodIV",5},{"ACE_epinephrine",10},{"ACE_morphine",10},{"ACE_surgicalKit",1},{"ACE_tourniquet",8},{"ACE_splint",8},{"ACE_bloodIV_250",2}};
	};

	class B_G_Soldier_F {
		// Requires the following DLC:
		// Apex
		displayName = "B_G_Soldier_F";

		primaryWeapon[] = {"CUP_arifle_FNFAL_woodland","","","",{"CUP_20Rnd_762x51_FNFAL_Woodland_M",20},{},""};
		secondaryWeapon[] = {};
		handgunWeapon[] = {};
		binocular = "Binocular";

		uniformClass = "tmtm_u_guerillaGarment_brownSand";
		headgearClass = "H_Simc_SVN_M1_Cl";
		vestClass = "tmtm_v_6b3PioneerGL_oliveCamo";
		backpackClass = "CUP_B_AlicePack_Bedroll";

		linkedItems[] = {"ItemMap","","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ACE_EntrenchingTool",1},{"ACE_MapTools",1}};
		vestItems[] = {{"SmokeShell",2,1},{"CUP_HandGrenade_M67",2,1},{"CUP_20Rnd_762x51_FNFAL_M",9,20}};
		backpackItems[] = {{"CUP_20Rnd_762x51_FNFAL_M",12,20}};

		basicMedUniform[] = {{"ACE_packingBandage",5},{"ACE_epinephrine",2},{"ACE_morphine",2},{"ACE_splint",2},{"ACE_tourniquet",2}};
		basicMedVest[] = {};
		basicMedBackpack[] = {};
	};

	class CUP_B_BAF_Soldier_Helipilot_DPM {
		// Requires the following DLC:
		// Apex
		displayName = "CUP_B_BAF_Soldier_Helipilot_DPM";

		primaryWeapon[] = {"CUP_smg_MP5A5","","","",{"CUP_30Rnd_9x19_MP5",30},{},""};
		secondaryWeapon[] = {};
		handgunWeapon[] = {"CUP_hgun_Glock17_blk","","","",{"CUP_17Rnd_9x19_glock17",17},{},""};

		uniformClass = "CUP_U_B_BAF_DPM_UBACSLONG";
		headgearClass = "CUP_H_SPH4";
		vestClass = "CUP_V_B_BAF_DPM_Osprey_Mk3_Pilot";
		backpackClass = "FRXA_tf_rt1523g_big_Ranger_Green";

		linkedItems[] = {"ItemMap","","TFAR_anprc152","ItemCompass","TFAR_microdagr",""};

		uniformItems[] = {{"ItemcTabHCam",1},{"ACE_MapTools",1}};
		vestItems[] = {{"CUP_30Rnd_9x19_MP5",8,30}};
		backpackItems[] = {{"ToolKit",1},{"SmokeShell",4,1},{"SmokeShellBlue",2,1},{"CUP_HandGrenade_M67",2,1}};

		basicMedUniform[] = {{"ACE_packingBandage",5},{"ACE_epinephrine",2},{"ACE_morphine",2},{"ACE_splint",4},{"ACE_tourniquet",4}};
		basicMedVest[] = {};
		basicMedBackpack[] = {};
	};
