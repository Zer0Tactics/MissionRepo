// Unit Insignias
// Usually visible on the sleeve of a unit
// https://community.bistudio.com/wiki/Arma_3_Unit_Insignia

/*
class example_insignia
{
	displayName = "Example";
	author = "Author";
	texture = "insignia.paa";
}
*/