// CfgRespawnTemplates.hpp
// Use this file to define any custom respawn templates to use in your mission