// Admin Console Access
// Admins defined within this file are given access to the "Mirage Coordinator" function within a mission.
// The ID used is the steam64ID of any players that are to have access to the console, in array format.

class cfgAdmins
{
	ids[] = {
		"76561198031434864"
	};
};