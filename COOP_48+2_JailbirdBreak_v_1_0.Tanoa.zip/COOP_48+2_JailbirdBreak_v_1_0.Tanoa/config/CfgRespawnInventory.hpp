// Respawn Inventories
// Used for giving a unit a custom inventory upon respawn.
// Mostly only used with the "MenuInventory" respawn template.
// https://community.bistudio.com/wiki/Arma_3_Respawn#Respawn_Templates