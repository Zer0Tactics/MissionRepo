// ORBAT Viewer
// Can be used for indicating the structure of a given side/team, as well as their map positions.
// https://community.bistudio.com/wiki/ORBAT_Viewer