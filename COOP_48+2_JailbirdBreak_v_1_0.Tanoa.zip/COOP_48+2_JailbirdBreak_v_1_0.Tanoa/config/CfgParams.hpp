// Mission parameters
// Available on mission lobby
// https://community.bistudio.com/wiki/Arma_3_Mission_Parameters

// Uncomment this block, and replace the example param if you're going to use custom mission parameters
/*
class header_mission
{
	title = "===== Mission Settings =====";
	values[] = {0};
	texts[] = {""};
	default = 0;
};
class example_param
{
	title = "Example Title";
	values[] = {1,2};
	texts[] = {"Example 1", "Example 2"};
	default = 1;
};
*/